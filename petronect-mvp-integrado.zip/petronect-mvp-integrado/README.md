# Petronect MVP Integrado

Pacote completo do protótipo:

- `frontend/` — React + Vite + TypeScript + Tailwind CSS + shadcn/ui + Zod + i18next.
- `backend/` — Node.js + TypeScript + API local/Serverless + persistência local + DynamoDB.

## 1. Subir o backend

Abra um terminal na pasta `backend`:

```powershell
npm install
Copy-Item .env.example .env
npm run dev
```

A API ficará em:

```text
http://localhost:3001
```

Teste:

```text
http://localhost:3001/health
```

## 2. Subir o frontend

Abra outro terminal na pasta `frontend`:

```powershell
npm install
Copy-Item .env.example .env
npm run dev
```

O Vite mostrará:

```text
http://localhost:5173
```

Abra esse endereço no navegador.

## Fluxo integrado

1. Login envia CNPJ/cargo para `POST /auth/login`.
2. O backend devolve `userId`, `supplierId`, CNPJ mascarado e cargo.
3. O frontend inicia uma sessão via `POST /session/start`.
4. Navegação e cliques usam `POST /events`.
5. O primeiro clique de cada página é registrado uma vez por sessão/página.
6. Heartbeats são enviados enquanto a aba está visível.
7. Dashboard usa `GET /analytics/dashboard`.
8. Detalhe do fornecedor usa `GET /analytics/suppliers/:supplierId`.
9. Logout usa `POST /session/end`.

## Rotas do frontend

- `/login`
- `/training`
- `/tools`
- `/dashboard`
- `/dashboard/supplier/:supplierId`

## Internacionalização

O frontend possui:

- `pt-BR`
- `en-US`

O botão de idioma fica no cabeçalho do portal.

## shadcn/ui

Os componentes estão em:

```text
frontend/src/components/ui/
```

Incluídos:

- Button
- Card
- Input
- Badge
- Table
- Tabs
- Select
- Dialog
- Tooltip
- Skeleton

O arquivo `components.json` permite continuar usando o padrão shadcn/ui.

## Zod

Zod é usado para:

- login;
- CNPJ no formulário;
- eventos;
- respostas da API;
- dashboard;
- detalhes de fornecedores.

## Observação importante

A validação definitiva do build depende de executar `npm install` em `frontend` e `backend`, pois este pacote não inclui `node_modules`.
