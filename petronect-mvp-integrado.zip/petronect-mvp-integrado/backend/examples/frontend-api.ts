const API_URL = "http://localhost:3001";

export async function login(cnpj: string, role: string) {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cnpj, role })
  });

  if (!response.ok) throw new Error("Falha no login");
  return response.json();
}

export async function startSession(userId: string, supplierId: string) {
  const response = await fetch(`${API_URL}/session/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, supplierId })
  });

  if (!response.ok) throw new Error("Falha ao iniciar sessão");
  return response.json();
}

export async function trackEvent(input: {
  sessionId: string;
  userId: string;
  supplierId: string;
  eventName: string;
  page?: string;
  section?: string;
  itemId?: string;
  keyword?: string;
  durationMs?: number;
  metadata?: Record<string, unknown>;
}) {
  const response = await fetch(`${API_URL}/events`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  });

  if (!response.ok) throw new Error("Falha ao registrar evento");
  return response.json();
}

export async function getDashboard() {
  const response = await fetch(`${API_URL}/analytics/dashboard`);
  if (!response.ok) throw new Error("Falha ao carregar dashboard");
  return response.json();
}
