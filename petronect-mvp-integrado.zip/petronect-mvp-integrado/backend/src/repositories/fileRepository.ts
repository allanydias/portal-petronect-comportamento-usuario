import { promises as fs } from "fs";
import path from "path";
import type { BehaviorEvent, Session, SupplierProfile, User } from "../types/domain";
import type { Repository } from "./repository";
import { buildSeedData } from "../mock/seed";

type LocalDb = {
  users: User[];
  sessions: Session[];
  events: BehaviorEvent[];
  profiles: SupplierProfile[];
};

export class FileRepository implements Repository {
  private filePath: string;

  constructor(filePath = process.env.LOCAL_DB_PATH || ".data/db.json") {
    this.filePath = path.resolve(process.cwd(), filePath);
  }

  async initialize(): Promise<void> {
    try {
      await fs.access(this.filePath);
    } catch {
      await this.reset();
    }
  }

  private async read(): Promise<LocalDb> {
    await this.initialize();
    const raw = await fs.readFile(this.filePath, "utf8");
    return JSON.parse(raw) as LocalDb;
  }

  private async write(db: LocalDb): Promise<void> {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    const temp = `${this.filePath}.tmp`;
    await fs.writeFile(temp, JSON.stringify(db, null, 2), "utf8");
    await fs.rename(temp, this.filePath);
  }

  async reset(): Promise<void> {
    const seed = buildSeedData();
    await this.write({
      ...seed,
      profiles: []
    });
  }

  async saveUser(user: User): Promise<User> {
    const db = await this.read();
    const index = db.users.findIndex((item) => item.userId === user.userId);
    if (index >= 0) db.users[index] = user;
    else db.users.push(user);
    await this.write(db);
    return user;
  }

  async getUser(userId: string): Promise<User | null> {
    const db = await this.read();
    return db.users.find((item) => item.userId === userId) ?? null;
  }

  async listUsers(): Promise<User[]> {
    return (await this.read()).users;
  }

  async saveSession(session: Session): Promise<Session> {
    const db = await this.read();
    const index = db.sessions.findIndex((item) => item.sessionId === session.sessionId);
    if (index >= 0) db.sessions[index] = session;
    else db.sessions.push(session);
    await this.write(db);
    return session;
  }

  async getSession(sessionId: string): Promise<Session | null> {
    const db = await this.read();
    return db.sessions.find((item) => item.sessionId === sessionId) ?? null;
  }

  async listSessions(): Promise<Session[]> {
    return (await this.read()).sessions;
  }

  async listSessionsBySupplier(supplierId: string): Promise<Session[]> {
    return (await this.read()).sessions.filter((item) => item.supplierId === supplierId);
  }

  async saveEvent(event: BehaviorEvent): Promise<BehaviorEvent> {
    const db = await this.read();
    if (!db.events.some((item) => item.eventId === event.eventId)) {
      db.events.push(event);
      await this.write(db);
    }
    return event;
  }

  async listEvents(): Promise<BehaviorEvent[]> {
    return (await this.read()).events;
  }

  async listEventsBySupplier(supplierId: string): Promise<BehaviorEvent[]> {
    return (await this.read()).events.filter((item) => item.supplierId === supplierId);
  }

  async listEventsBySession(sessionId: string): Promise<BehaviorEvent[]> {
    return (await this.read()).events.filter((item) => item.sessionId === sessionId);
  }

  async saveProfile(profile: SupplierProfile): Promise<SupplierProfile> {
    const db = await this.read();
    const index = db.profiles.findIndex((item) => item.supplierId === profile.supplierId);
    if (index >= 0) db.profiles[index] = profile;
    else db.profiles.push(profile);
    await this.write(db);
    return profile;
  }

  async getProfile(supplierId: string): Promise<SupplierProfile | null> {
    const db = await this.read();
    return db.profiles.find((item) => item.supplierId === supplierId) ?? null;
  }
}
