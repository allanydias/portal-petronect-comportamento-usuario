import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SessionProvider } from "@/contexts/SessionContext";
import App from "@/App";
import "@/index.css";
import "@/i18n";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <TooltipProvider>
        <SessionProvider>
          <App />
        </SessionProvider>
      </TooltipProvider>
    </BrowserRouter>
  </React.StrictMode>
);
